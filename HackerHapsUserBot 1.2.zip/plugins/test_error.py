from telethon import events
import traceback

@events.register(events.NewMessage(pattern=r"^\.testerror$"))
async def test_error_handler(event):
    if not event.out:
        return  # реагируем только на владельца

    try:
        # Искусственно вызываем ошибку — деление на ноль
        1 / 0
    except Exception:
        tb = traceback.format_exc()  # Получаем полный traceback ошибки
        # Отправляем сообщение с цитатой (кодом) и сообщением об ошибке
        error_text = f"❌ Произошла ошибка в модуле test:\n\n<pre>{tb}</pre>"
        await event.reply(error_text, parse_mode="html")


def setup(client):
    client.add_event_handler(test_error_handler)