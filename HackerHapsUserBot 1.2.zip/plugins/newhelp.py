import os
import re
from telethon import events
from telethon.tl.types import MessageMediaDocument
from telethon.errors import MessageNotModifiedError
import importlib.util
import sys

PLUGINS_DIR = "./plugins"  # Папка для плагинов

if not os.path.exists(PLUGINS_DIR):
    os.makedirs(PLUGINS_DIR)


async def install_module(event):
    if not event.out:
        try:
            await event.edit("❌ У вас нет прав на установку модулей. Команда доступна только владельцу бота.")
        except MessageNotModifiedError:
            pass
        return

    if not event.is_reply:
        try:
            await event.edit("❗️ Ответьте командой .lm на сообщение с файлом модуля (.py)")
        except MessageNotModifiedError:
            pass
        return

    reply = await event.get_reply_message()

    if not reply or not reply.media or not isinstance(reply.media, MessageMediaDocument):
        try:
            await event.edit("❗️ В ответе должно быть сообщение с файлом модуля (.py)")
        except MessageNotModifiedError:
            pass
        return

    filename = reply.file.name or "module.py"
    if not filename.endswith(".py"):
        try:
            await event.edit("❗️ Файл должен иметь расширение .py")
        except MessageNotModifiedError:
            pass
        return

    me = await event.client.get_me()
    if reply.sender_id != me.id:
        try:
            await event.edit("❌ Вы не можете устанавливать модули, скинутые другими пользователями.")
        except MessageNotModifiedError:
            pass
        return

    try:
        await event.edit("⬇️ Скачивание модуля...")
    except MessageNotModifiedError:
        pass

    path = os.path.join(PLUGINS_DIR, filename)

    try:
        await event.client.download_media(reply.media, path)

        try:
            await event.edit("⬇️ Модуль скачан. Анализирую команды...")
        except MessageNotModifiedError:
            pass

        module_name = os.path.splitext(filename)[0]

        builtin_commands = {"help", "info", "restart", "lm", "about", "start"}
        if module_name.lower() in builtin_commands:
            try:
                await event.edit(
                    "⚠️ Этот модуль пытается заменить встроенную команду (.) — установка отменена."
                )
            except MessageNotModifiedError:
                pass
            os.remove(path)
            return

        # Загрузить модуль
        spec = importlib.util.spec_from_file_location(module_name, path)
        if spec is None:
            raise Exception("Не удалось получить спецификацию модуля.")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        sys.modules[module_name] = module

        if not (hasattr(module, "setup") and callable(module.setup)):
            try:
                await event.edit(
                    "⚠️ Модуль установлен, но функция <i>setup(client)</i> не найдена. Обработчики не зарегистрированы.",
                    parse_mode="html"
                )
            except MessageNotModifiedError:
                pass
            return

        module.setup(event.client)

        # Попытаться получить список команд из атрибута commands
        commands = []
        if hasattr(module, "commands") and isinstance(module.commands, (list, tuple)):
            commands = module.commands
        else:
            # Если нет атрибута, парсим код файла для поиска команд
            with open(path, "r", encoding="utf-8") as f:
                code = f.read()

            # Ищем паттерны команд из обработчиков Telethon: pattern=r"^\.(command)(?:\s|$)"
            pattern = re.compile(r'pattern\s*=\s*r?["\']\^\\\.(\w+)(?:\\s|\$)')
            found = pattern.findall(code)

            # Альтернативный поиск команд в виде '.command' в строках кода (обычные команды)
            if not found:
                found = re.findall(r'\.(\w+)', code)

            commands = list(set(found))

        if commands:
            commands_text = "\n".join(
                f"<i><code>.{cmd}</code></i> — команда модуля" for cmd in sorted(commands)
            )
        else:
            commands_text = (
                f"<i><code>.{module_name}</code></i> — основная команда модуля\n"
                f"<i><code>.{module_name} help</code></i> — помощь по модулю"
            )

        info_text = (
            f"✅ Модуль <b>{module_name}</b> успешно установлен и загружен!\n\n"
            f"📦 Доступные команды:\n"
            f"{commands_text}\n\n"
            "ℹ️ Используйте команды с точкой и названием модуля."
        )

        try:
            await event.edit(info_text, parse_mode="html")
        except MessageNotModifiedError:
            pass

    except Exception as e:
        if os.path.exists(path):
            os.remove(path)
        try:
            await event.edit(f"❌ Ошибка при установке модуля:\n{e}")
        except MessageNotModifiedError:
            pass


def setup(client):
    client.add_event_handler(
        install_module,
        events.NewMessage(pattern=r"^\.lm(?:\s|$)")
    )