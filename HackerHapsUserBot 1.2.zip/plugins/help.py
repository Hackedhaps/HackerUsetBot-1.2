
from telethon import events
import os
import importlib.util

async def help_handler(event):
    if not event.out:
        return  # Отвечаем только на свои сообщения

    plugins_dir = "./plugins"
    total_modules = 0
    commands_list = []

    try:
        files = [
            f for f in os.listdir(plugins_dir)
            if f.endswith(".py") and not f.startswith("_") and f != "init.py"
        ]
        total_modules = len(files)

        for f in files:
            module_name = os.path.splitext(f)[0]
            path = os.path.join(plugins_dir, f)
            spec = importlib.util.spec_from_file_location(module_name, path)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)

            if hasattr(module, "commands") and isinstance(module.commands, (list, tuple)):
                for cmd in module.commands:
                    if cmd not in commands_list:
                        commands_list.append(cmd)
            else:
                cmd = module_name
                if cmd not in commands_list:
                    commands_list.append(cmd)

    except Exception:
        total_modules = 0

    commands_text = ""
    if commands_list:
        for cmd in sorted(commands_list):
            commands_text += f"> .{cmd} — команда модуля\n"

    commands_text += (
        "> .help — показать помощь\n"
        "> .about — информация о сервере и работе UserBot\n"
    )

    help_text = (
        f"✨ {total_modules} модулей доступно, 0 скрыто:\n\n"
        "> help помощь.\n\n"
        "Доступные команды:\n"
        f"{commands_text}"
    )

    try:
        await event.edit(help_text)
    except Exception as e:
        await event.reply(f"Ошибка при отправке сообщения: {e}")

def setup(client):
    client.add_event_handler(
        help_handler,
        events.NewMessage(pattern=r"^\.(help)(?:\s|$)")
    )