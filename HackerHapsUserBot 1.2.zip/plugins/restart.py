import time
import asyncio
import sys
from telethon import events

async def restart_handler(event):
    # Реагируем только на сообщения от владельца (исходящие)
    if not event.out:
        return

    msg = await event.reply("♻️ Перезагружается бот...")

    start_time = time.monotonic()

    # Имитация задержки перезагрузки (можно убрать, если не нужна)
    await asyncio.sleep(1.5)

    elapsed = time.monotonic() - start_time

    try:
        await msg.edit(f"✅ Бот перезагружен! Заняло {elapsed:.2f} секунд.")
    except Exception:
        pass

    # Перезапуск скрипта бота (быстрая перезагрузка)
    # Важно: при запуске бота нужно использовать этот же файл, чтобы перезапуск работал корректно
    python = sys.executable
    os_args = sys.argv

    # Закрываем текущий процесс и запускаем новый
    os.execv(python, [python] + os_args)


def setup(client):
    client.add_event_handler(
        restart_handler,
        events.NewMessage(pattern=r"^\.restart(?:\s|$)")
    )