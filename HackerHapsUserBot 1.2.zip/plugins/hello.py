
from telethon import events

async def hello_handler(event):
    # Проверяем — сообщение должно быть отправлено самим юзерботом
    if not event.out:
        return  # Игнорируем сообщения других пользователей

    try:
        await event.edit("Привет! Это плагин hello.")
    except Exception:
        await event.reply("Привет! Это плагин hello.")

def setup(client):
    client.add_event_handler(
        hello_handler,
        events.NewMessage(pattern=r"^\.(hello)(?:\s|$)")
    )