
from telethon import events, TelegramClient
import asyncio
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

stay_online_task = None  # Глобальная переменная для задачи

async def keep_online(client):
    while True:
        try:
            # Запрашиваем информацию о себе, чтобы поддерживать сессию
            me = await client.get_me()
            logger.info(f"Пинг Telegram для пользователя @{me.username} успешен")
        except Exception as e:
            logger.error(f"Ошибка при поддержании онлайн: {e}")
        await asyncio.sleep(30)  # Пауза 30 секунд

@events.register(events.NewMessage(pattern=r"^\.stayonline$"))
async def stay_online_handler(event):
    global stay_online_task
    if not event.out:
        return  # Отвечаем только на свои сообщения

    client = event.client

    if stay_online_task and not stay_online_task.done():
        await event.reply("⚠️ Задача поддержания онлайн уже запущена.")
        return

    stay_online_task = asyncio.create_task(keep_online(client))
    await event.reply("✅ Задача поддержания онлайн запущена. Бот будет оставаться в сети пока работает.")

@events.register(events.NewMessage(pattern=r"^\.stopstayonline$"))
async def stop_stay_online_handler(event):
    global stay_online_task
    if not event.out:
        return

    if stay_online_task and not stay_online_task.done():
        stay_online_task.cancel()
        await event.reply("🛑 Задача поддержания онлайн остановлена.")
    else:
        await event.reply("ℹ️ Задача поддержания онлайн не была запущена.")

def setup(client: TelegramClient):
    client.add_event_handler(stay_online_handler)
    client.add_event_handler(stop_stay_online_handler)