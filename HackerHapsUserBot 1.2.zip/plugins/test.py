from telethon import events

async def test_handler(event):
    if not event.out:
        return
    await event.edit("✅ Команда .test всё работает! 🔥")

def setup(client):
    client.add_event_handler(
        test_handler,
        events.NewMessage(pattern=r"^\.test(?:\s|$)")
    )