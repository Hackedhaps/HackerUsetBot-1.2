from telethon import events
from datetime import datetime, timedelta

module_name = "Информация о сервере"
commands = {
    ".about": "Показать информацию о сервере и работе UserBot"
}

async def about_handler(event):
    if not event.out:
        return

    current_time = datetime.now().strftime("%H:%M:%S")
    unloading_duration = timedelta(hours=3, minutes=49, seconds=0)
    unloading_time = (datetime.now() + unloading_duration).strftime("%H:%M:%S")

    about_text = (
        "<b>ℹ️ Информация о сервере и работе UserBot</b>\n\n"
        "<blockquote>"
        f"⏳ server loading: <i>{current_time}</i>\n"
        f"⚙️ servers unloading: <i>{unloading_time}</i>"
        "</blockquote>\n\n"
        "<b>Команда:</b> <code>.about</code>"
    )

    try:
        await event.edit(about_text, parse_mode="html")
    except Exception as e:
        await event.reply(f"Ошибка: {e}")

def setup(client):
    client.add_event_handler(
        about_handler,
        events.NewMessage(pattern=r"^\.(about)(?:\s|$)")
    )